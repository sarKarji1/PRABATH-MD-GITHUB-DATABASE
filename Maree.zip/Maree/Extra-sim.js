import axios from 'axios';
import config from '../../config.js';
import { sendNewsletter } from '../Sarkar/newsletter.js';

const simCommand = async (m, sock) => {
    const prefix = config.PREFIX;
    const isCmd = m.body.startsWith(prefix) 
        ? m.body.slice(prefix.length).split(' ')[0].toLowerCase()
        : '';
    const query = m.body.slice(prefix.length + isCmd.length).trim();

    if (isCmd !== 'sim') return;

    try {
        if (!query) {
            await sendNewsletter(
                sock,
                m.from,
                "📱 *SIM Information Lookup*\n\nUsage: `.sim [number/cnic]`\nExamples:\n`.sim 3001234567` (for mobile number)\n`.sim 1234567890123` (for CNIC)",
                m,
                "SIM Command Help",
                "Query Required"
            );
            return;
        }

        // Validate input - should be 10/11 digit number or 13 digit CNIC
        if (!/^\d{10,13}$/.test(query)) {
            await m.reply('❌ Invalid input. Please provide:\n- 10/11 digit mobile number\n- 13 digit CNIC');
            return;
        }

        await sock.sendPresenceUpdate('composing', m.from);
        await m.React('🔍');

        const apiUrl = `https://fam-official.serv00.net/sim/newsimdata.php?num=${query}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status !== 'success' || !data.data || data.data.length === 0) {
            throw new Error(data.message || 'No data found');
        }

        // Format the response
        let resultMessage = `📌 *SIM Information for ${query}*\n\n`;
        resultMessage += `🔢 *Total Records Found:* ${data.data.length}\n\n`;

        data.data.forEach((record, index) => {
            resultMessage += `*Record ${index + 1}:*\n`;
            resultMessage += `📱 *Mobile:* ${record.mobile || 'Not Available'}\n`;
            resultMessage += `👤 *Name:* ${record.name || 'Not Available'}\n`;
            resultMessage += `🆔 *CNIC:* ${record.cnic || 'Not Available'}\n`;
            resultMessage += `🏠 *Address:* ${record.address || 'Not Available'}\n\n`;
        });

        resultMessage += `_KEEP USING SARKAR-MD_`;

        await sendNewsletter(
                sock,
                m.from,
                resultMessage,
                m,
                "SIM Info Command",
                "Sarkar-MD"
            );

        await m.React('✅');

    } catch (error) {
        console.error('SIM Command Error:', error);
        await sendNewsletter(
            sock,
            m.from,
            `❌ *SIM Lookup Failed*\n\nError: ${error.message}\n\nPlease check:\n- Valid 10/11 digit number or 13 digit CNIC\n- Try again later`,
            m,
            "SIM Lookup Error",
            "Try Again"
        );
        await m.React('❌');
    }
};

export default simCommand;